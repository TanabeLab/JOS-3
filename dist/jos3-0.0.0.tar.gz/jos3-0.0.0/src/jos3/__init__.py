# -*- coding: utf-8 -*-
from jos3.jos3 import *
__version__ = '0.0.0'